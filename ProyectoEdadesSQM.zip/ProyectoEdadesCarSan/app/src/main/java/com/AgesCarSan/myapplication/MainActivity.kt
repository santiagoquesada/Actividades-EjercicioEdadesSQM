package com.AgesCarSan.myapplication

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    var telefono: EditText? = null
    var nombre: EditText? = null
    var email: EditText? = null
    var documento: EditText? = null
    var edad: EditText? = null
    var datos: TextView? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        telefono = findViewById(R.id.Telefono)
        nombre = findViewById(R.id.Nombre)
        email = findViewById(R.id.Email)
        documento = findViewById(R.id.Documento)
        edad = findViewById(R.id.Edad)
        datos = findViewById(R.id.Datos)

        var miButton: Button = findViewById(R.id.Ingresar)
        miButton.setOnClickListener { onClick() }

    }

    private fun onClick() {
        var telefonoF: Int = telefono?.text.toString().toInt()
        var nombreF: String = nombre?.text.toString()
        var emailF: String = email?.text.toString()
        var documentoF: Int = documento?.text.toString().toInt()
        var edadF: Int = edad?.text.toString().toInt()
        var edadVal = edadF
        datos!!.text= "!Bienvenido!, $nombreF \n Telefono: $telefonoF \n Correo: $emailF \n Documento: $documentoF \n Edad: $edadF"
        if (edadVal >= 0 && edadF < 15 ){
            Toast.makeText(this, "SU EDAD ES: $edadF \n USTED ES INFANTE", Toast.LENGTH_SHORT).show()
        }
        if (edadF >= 16 && edadF <= 18){
            Toast.makeText(this, "SU EDAD ES: $edadF \n USTED ES ADOLESCENTE" , Toast.LENGTH_SHORT).show()
        }
        if (edadF >= 19 && edadF <= 65){
            Toast.makeText(this, "SU EDAD ES: $edadF \n USTED ES ADULTO" , Toast.LENGTH_SHORT).show()
        }
        if (edadF >= 65 && edadF <= 120){
            Toast.makeText(this, "SU EDAD ES: $edadF \n USTED ES ADULTO MAY2" , Toast.LENGTH_SHORT).show()
        }
    }
}